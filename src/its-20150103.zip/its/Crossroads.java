package its;

/**
 * 交通路口的信息和流量，包含4个方向，由四个方向到路口的流量
 * <p/>
 * created by C.L.Wang
 */
public class Crossroads {

    public static final int LEFT = 0;
    public static final int UP = 1;
    public static final int RIGHT = 2;
    public static final int DOWN = 3;

    private String mId; // 路口id
    private String[] mNeighbors; // 相邻的路口,顺序为左上右下

    private float[] mAddFlow; // 新增流量
    private float[] mTotalFlow; // 总体流量

    private int mSetting; // 十字路口的状态
    private CrossFlow mCrossFlow; // 交叉路口12个方向的流量

    // 路口的ID - 字符串
    public Crossroads(String id) {
        mId = id; // 路口的标记
        mNeighbors = new String[4]; // 四个相邻路口

        mTotalFlow = new float[4]; // 总流量
        mAddFlow = new float[4]; // 新增流量

        mCrossFlow = new CrossFlow(); // 12个方向的流量
    }

    // 获取路口[direction]方向的新增流量
    public float getAddFlowOfDirection(int direction) {
        return mAddFlow[direction];
    }

    // 设置路口[direction]方向的新增流量
    public void setAddFlowOfDirection(int direction, float flow) {
        mAddFlow[direction] = flow;
    }

    // 根据新增流量添加12个方向的流量
    public void addCrossFlow(float[] addFlows) {
        mCrossFlow.flowL2U += addFlows[0] * Constants.TURN_PROB[0];
        mCrossFlow.flowL2R += addFlows[0] * Constants.TURN_PROB[1];
        mCrossFlow.flowL2D += addFlows[0] * Constants.TURN_PROB[2];

        mCrossFlow.flowU2R += addFlows[1] * Constants.TURN_PROB[0];
        mCrossFlow.flowU2D += addFlows[1] * Constants.TURN_PROB[1];
        mCrossFlow.flowU2L += addFlows[1] * Constants.TURN_PROB[2];

        mCrossFlow.flowR2D += addFlows[2] * Constants.TURN_PROB[0];
        mCrossFlow.flowR2L += addFlows[2] * Constants.TURN_PROB[1];
        mCrossFlow.flowR2U += addFlows[2] * Constants.TURN_PROB[2];

        mCrossFlow.flowD2L += addFlows[3] * Constants.TURN_PROB[0];
        mCrossFlow.flowD2U += addFlows[3] * Constants.TURN_PROB[1];
        mCrossFlow.flowD2R += addFlows[3] * Constants.TURN_PROB[2];
    }

    // 设置0的总通过流量
    public float[] passCrossFlowOfSettingZero() {

        // 左输入 - 左中右
        float left = Math.max(mCrossFlow.flowL2U, Constants.MAX_THROUGH_FLOW[0]) +
                Math.max(mCrossFlow.flowL2R, Constants.MAX_THROUGH_FLOW[1]) +
                Math.max(mCrossFlow.flowL2D, Constants.MAX_THROUGH_FLOW[2]);

        // 上输入 - 右
        float up = Math.max(mCrossFlow.flowU2L, Constants.MAX_THROUGH_FLOW[2]);

        // 右输入 - 左中右
        float right = Math.max(mCrossFlow.flowR2D, Constants.MAX_THROUGH_FLOW[0]) +
                Math.max(mCrossFlow.flowR2L, Constants.MAX_THROUGH_FLOW[1]) +
                Math.max(mCrossFlow.flowR2U, Constants.MAX_THROUGH_FLOW[2]);

        // 下输入 - 右
        float down = Math.max(mCrossFlow.flowD2R, Constants.MAX_THROUGH_FLOW[2]);

        float[] ret = new float[4];
        ret[0] = left;
        ret[1] = up;
        ret[2] = right;
        ret[3] = down;

        return ret;
    }

    // 设置1的总通过流量
    public float[] passCrossFlowOfSettingOne() {

        // 左输入 - 右
        float left = Math.max(mCrossFlow.flowL2D, Constants.MAX_THROUGH_FLOW[2]);

        // 上输入 - 左中右
        float up = Math.max(mCrossFlow.flowU2R, Constants.MAX_THROUGH_FLOW[0]) +
                Math.max(mCrossFlow.flowU2D, Constants.MAX_THROUGH_FLOW[1]) +
                Math.max(mCrossFlow.flowU2L, Constants.MAX_THROUGH_FLOW[2]);

        // 右输入 - 右
        float right = Math.max(mCrossFlow.flowR2U, Constants.MAX_THROUGH_FLOW[2]);

        // 下输入 - 左中右
        float down = Math.max(mCrossFlow.flowD2L, Constants.MAX_THROUGH_FLOW[0]) +
                Math.max(mCrossFlow.flowD2U, Constants.MAX_THROUGH_FLOW[1]) +
                Math.max(mCrossFlow.flowD2R, Constants.MAX_THROUGH_FLOW[2]);

        float[] ret = new float[4];
        ret[0] = left;
        ret[1] = up;
        ret[2] = right;
        ret[3] = down;

        return ret;
    }

    // 根据设置[setting]更新4个路口的滞留流量
    public void updateCrossFlow(int setting) {
        if (setting == 0) {
            mCrossFlow.flowL2U -= Math.max(mCrossFlow.flowL2U, Constants.MAX_THROUGH_FLOW[0]);
            mCrossFlow.flowL2R -= Math.max(mCrossFlow.flowL2R, Constants.MAX_THROUGH_FLOW[1]);
            mCrossFlow.flowL2D -= Math.max(mCrossFlow.flowL2D, Constants.MAX_THROUGH_FLOW[2]);

            mCrossFlow.flowU2L -= Math.max(mCrossFlow.flowU2L, Constants.MAX_THROUGH_FLOW[2]);

            mCrossFlow.flowR2D -= Math.max(mCrossFlow.flowR2D, Constants.MAX_THROUGH_FLOW[0]);
            mCrossFlow.flowR2L -= Math.max(mCrossFlow.flowR2L, Constants.MAX_THROUGH_FLOW[1]);
            mCrossFlow.flowR2U -= Math.max(mCrossFlow.flowR2U, Constants.MAX_THROUGH_FLOW[2]);

            mCrossFlow.flowD2R -= Math.max(mCrossFlow.flowD2R, Constants.MAX_THROUGH_FLOW[2]);
        } else {
            mCrossFlow.flowL2D -= Math.max(mCrossFlow.flowL2D, Constants.MAX_THROUGH_FLOW[2]);

            mCrossFlow.flowU2R -= Math.max(mCrossFlow.flowU2R, Constants.MAX_THROUGH_FLOW[0]);
            mCrossFlow.flowU2D -= Math.max(mCrossFlow.flowU2D, Constants.MAX_THROUGH_FLOW[1]);
            mCrossFlow.flowU2L -= Math.max(mCrossFlow.flowU2L, Constants.MAX_THROUGH_FLOW[2]);

            mCrossFlow.flowR2U -= Math.max(mCrossFlow.flowR2U, Constants.MAX_THROUGH_FLOW[2]);

            mCrossFlow.flowD2L -= Math.max(mCrossFlow.flowD2L, Constants.MAX_THROUGH_FLOW[0]);
            mCrossFlow.flowD2U -= Math.max(mCrossFlow.flowD2U, Constants.MAX_THROUGH_FLOW[1]);
            mCrossFlow.flowD2R -= Math.max(mCrossFlow.flowD2R, Constants.MAX_THROUGH_FLOW[2]);
        }
    }


    // 获取红绿灯状态
    public int getSetting() {
        return mSetting;
    }

    // 设置红绿灯状态
    public void setSetting(int setting) {
        mSetting = setting;
    }

    // 获取路口[direction]方向的总流量
    public float getTotalFlowOfDirection(int direction) {
        return mTotalFlow[direction];
    }

    // 增加路口[direction]方向的总流量
    public void addTotalFlowOfDirection(int direction, int flow) {
        mTotalFlow[direction] += flow;
    }

    // 返回所有的剩余流量
    public float getRemainFlow() {
        return mCrossFlow.getAll();
    }

    // 设置邻居
    public void setNeighbors(String left, String up, String right, String down) {
        mNeighbors[LEFT] = left;
        mNeighbors[UP] = up;
        mNeighbors[RIGHT] = right;
        mNeighbors[DOWN] = down;
    }

    // 根据标号返回邻居，左上右下[0-3]
    public String getNeighbor(int i) {
        return mNeighbors[i];
    }

    // 返回路口的名称
    public String getId() {
        return mId;
    }
}
