package its;

import java.util.*;

/**
 * 核心算法
 * <p/>
 * created by C.L.Wang
 */
public class Algorithms {

    @Deprecated
    public static void Solve(TrafficInfo trafficInfo, int time) {

        // 获取当前流量的集合
        Map<String, float[]> curFlowSet = trafficInfo.getCurFlowSet();


        for (String id : curFlowSet.keySet()) {

            Crossroads crossSet = trafficInfo.getCrossesSet().get(id);

            float[] curFlows = curFlowSet.get(id);

            float curHorizon = curFlows[0] + curFlows[2];
            float curVertical = curFlows[1] + curFlows[3];

            float curDiff = curHorizon - curVertical;

            int setting = curDiff > 0 ? 0 : 1;

            float subLeft, subUp, subRight, subDown;
            if (setting == 0) {
                subLeft = curFlows[0] * (0.8f + 0.1f);
                subUp = curFlows[1] * (0.1f);
                subRight = curFlows[2] * (0.8f + 0.1f);
                subDown = curFlows[3] * (0.1f);
            } else {
                subLeft = curFlows[0] * (0.1f);
                subUp = curFlows[1] * (0.8f + 0.1f);
                subRight = curFlows[2] * (0.1f);
                subDown = curFlows[3] * (0.8f + 0.1f);
            }

            crossSet.subCurFlowOfDirection(Crossroads.LEFT, subLeft > 18.0f ? 18.0f : subLeft);
            crossSet.subCurFlowOfDirection(Crossroads.UP, subUp > 18.0f ? 18.0f : subUp);
            crossSet.subCurFlowOfDirection(Crossroads.RIGHT, subRight > 18.0f ? 18.0f : subRight);
            crossSet.subCurFlowOfDirection(Crossroads.DOWN, subDown > 18.0f ? 18.0f : subDown);
            crossSet.setSetting(setting);
        }
    }

    public static void Solve2(TrafficInfo trafficInfo, int time) {

        // 获取新增流量的集合
        Map<String, float[]> addFlowSet = trafficInfo.getAddFlowSet();

        // 当前总流量
        Map<String, float[]> curFlowSet = trafficInfo.getCurFlowSet();

        for (String id : addFlowSet.keySet()) {

            Crossroads crossSet = trafficInfo.getCrossesSet().get(id);

            float[] curFlows = curFlowSet.get(id); // 当前总流量
            float curHorizon = curFlows[0] + curFlows[2]; // 当前水平总流量
            float curVertical = curFlows[1] + curFlows[3]; // 当前竖直总流量

            float probHorizon = (curHorizon) / (curHorizon + curVertical);
            float probVertical = (curVertical) / (curHorizon + curVertical);

            float[] addFlows = addFlowSet.get(id);
            crossSet.addCrossFlow(addFlows); // 添加12个方向的流量

            float[] f0 = crossSet.passCrossFlowOfSettingZero(); // 设置0的预计通过流量
            float[] f1 = crossSet.passCrossFlowOfSettingOne(); // 设置1的预计通过流量

            float total0 = 0.0f, total1 = 0.0f;

            for (float f : f0) {
                total0 += f;
            }

            for (float f : f1) {
                total1 += f;
            }

            int setting = (total0 - total1) > 0 ? 0 : 1;
            crossSet.updateCrossFlow(setting);
            crossSet.setSetting(setting);
        }
    }

}
